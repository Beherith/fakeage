# fakeage
fakeage


Simple python websockets lying game

to run a server, launch fakeage_server.py

Then navigate your brower to http://[my.local.ip]:8000/

Have fun!
