function get_websocket_ip(){
	return "ws://152.66.253.59:8001/"
}